/* Udel T'boli search: results show up as you type, matching words that START with what you typed.
   Row format in words.js (window.UDEL):
   [type 0=T'boli 1=English, word, url, equivalent, also, keys, unconfirmed, flag, related ids, meaning text, equivalent url, note]
   flag: English 1 = closest only, 2 = no T'boli word yet; T'boli 3 = word seen only inside phrases. */
(function () {
  var UI = window.UDEL_UI || {};
  var ROOT = new URL(window.UDEL_ROOT || '', location.href).href;
  var MAX = 40;
  var rows = null, cache = {}, current = '';

  function norm(s) {
    return (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/['\u2019\u2018`]/g, '').replace(/\s+/g, ' ').trim();
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }
  function bi(pair, fb) { pair = pair || fb; return esc(pair[0]) + ' <span class="tb" lang="tbl">' + esc(pair[1]) + '</span>'; }
  function href(u) { return u ? new URL(u, ROOT).href : ''; }
  function badge() { return ' <span class="badge sm">' + bi(UI.unconf, ['Unconfirmed', 'L\u00e0 deng tahu']) + '</span>'; }

  function prep() {
    if (rows || !window.UDEL) return !!rows;
    rows = window.UDEL.map(function (r, i) {
      var keys = r[0] === 1 ? [norm(r[1])] : (r[5] || norm(r[1])).split('|');
      if (keys.indexOf(norm(r[1])) < 0) keys.unshift(norm(r[1]));
      return { r: r, i: i, keys: keys, word: r[1], en: r[0] === 1, multi: /\s/.test(keys[0]),
        hay: ' ' + norm([r[3], r[4], r[9]].join(' ')) + ' ' };
    });
    return true;
  }

  // underline the part of the word that was typed (accents and apostrophes kept as written)
  function mark(word, q) {
    var n = 0, i = 0;
    if (norm(word).indexOf(q) !== 0) return esc(word);
    for (; i < word.length && n < q.length; i++) n += norm(word[i]).length || (word[i] === ' ' ? 1 : 0);
    return '<u>' + esc(word.slice(0, i)) + '</u>' + esc(word.slice(i));
  }

  function find(q) {
    var exact = [], pre = [], other = [];
    rows.forEach(function (x) {
      var hit = null;
      for (var k = 0; k < x.keys.length; k++) {
        if (x.keys[k] === q) { hit = 'e'; break; }
        if (x.keys[k].indexOf(q) === 0) hit = hit || x.keys[k];
      }
      if (hit === 'e') { exact.push(x); pre.push({ x: x, k: q }); }
      else if (hit) pre.push({ x: x, k: hit });
      else if (q.length > 1 && x.hay.indexOf(' ' + q) > -1) other.push(x);
    });
    pre.sort(function (a, b) {
      var ea = a.k === q ? 0 : 1, eb = b.k === q ? 0 : 1;
      if (ea !== eb) return ea - eb;
      if (a.k !== b.k) return a.k < b.k ? -1 : 1;
      if (a.x.en !== b.x.en) return a.x.en ? 1 : -1;
      return a.x.i - b.x.i;
    });
    other.sort(function (a, b) {
      var wa = a.hay.indexOf(' ' + q + ' ') > -1 ? 0 : 1, wb = b.hay.indexOf(' ' + q + ' ') > -1 ? 0 : 1;
      return wa - wb || (a.multi - b.multi) || (norm(a.word) < norm(b.word) ? -1 : 1);
    });
    // one card per language, T'boli first, single words before phrases
    exact.sort(function (a, b) { return (a.multi - b.multi) || (a.en - b.en) || a.i - b.i; });
    var cards = [], seen = {};
    exact.forEach(function (x) { if (!seen[x.en] && cards.length < 2) { seen[x.en] = 1; cards.push(x); } });
    return { cards: cards, pre: pre.map(function (p) { return p.x; }), other: other };
  }

  function line(x, q) {
    var r = x.r, tag = x.en ? '<i class="lg en">English</i>' : '<i class="lg">T\'boli</i>';
    var word = q ? mark(r[1], q) : esc(r[1]);
    var right;
    if (x.en) right = '<span class="eqs">= </span><b lang="tbl">' + (r[3] ? esc(r[3]) : '<span class="muted">no T\'boli word yet</span>') + '</b>';
    else right = '<span>' + esc(r[3] || r[11] || '') + '</span>';
    var lhs = x.en ? '<span class="enw">' + word + '</span>' : '<b lang="tbl">' + word + '</b>';
    return '<li><a href="' + href(r[2]) + '">' + tag + lhs + ' ' + right + '</a>' + (r[6] ? badge() : '') + '</li>';
  }

  function relLine(i) {
    var r = window.UDEL[i];
    if (!r) return '';
    if (r[0] === 1) return '<li><a href="' + href(r[2]) + '"><span>' + esc(r[1]) + '</span> <span class="muted">=</span> <b lang="tbl">' + esc(r[3] || '\u2026') + '</b></a></li>';
    return '<li><a href="' + href(r[2]) + '"><b lang="tbl">' + esc(r[1]) + '</b> <span>' + esc(r[3] || r[11] || '') + '</span></a>' + (r[6] ? badge() : '') + '</li>';
  }

  function card(x, n) {
    var r = x.r, h = '<section class="card best">';
    h += '<p class="bestw">' + (x.en ? '<span class="enw">' + esc(r[1]) + '</span>' : '<a lang="tbl" href="' + href(r[2]) + '">' + esc(r[1]) + '</a>') + (r[6] ? badge() : '') + '</p>';
    h += '<div class="equiv"><p class="eqlab">' + (x.en ? 'T\'boli <span class="tb" lang="tbl">Ud\u00e9l T\'boli</span>' : bi(UI.english, ['English', 'Ud\u00e9l English'])) + '</p>';
    if (x.en) {
      if (r[3]) h += '<p class="eqbig"><a class="eqw" lang="tbl" href="' + href(r[10] || r[2]) + '">' + esc(r[3]) + '</a></p>';
      else h += '<p class="eqbig"><span class="none">No T\'boli word yet</span></p>';
      if (r[4]) h += '<p class="also">Also: <span lang="tbl">' + esc(r[4]) + '</span></p>';
      if (r[7] === 1) h += '<p class="eqnote">No single T\'boli word for this: this is the closest the dictionary gives.</p>';
      if (r[7] === 2 && r[11]) h += '<p class="eqnote">' + esc(r[11]) + '</p>';
    } else {
      if (r[7] === 3) h += '<p class="eqbig"><span class="none">No meaning of its own written down yet</span></p><p class="eqnote">It appears ' + esc(r[11]) + '.</p>';
      else h += '<p class="eqbig"><span class="eqe">' + esc(r[3] || '') + '</span></p>';
      if (r[4]) h += '<p class="also">Also: ' + esc(r[4]) + '</p>';
      if (r[7] !== 3 && r[11]) h += '<p class="eqnote">' + esc(r[11].charAt(0).toUpperCase() + r[11].slice(1)) + '.</p>';
    }
    h += '</div>';
    if (r[8] && r[8].length) h += '<h2 class="relh">Related words and forms</h2><ul class="wl rl">' + r[8].map(relLine).join('') + '</ul>';
    h += '<div class="explain" id="ex' + n + '"></div>';
    h += '<p class="more"><a href="' + href(r[2]) + '">Open the full page \u2192</a></p></section>';
    return h;
  }

  // the explanation (how it is used, grammar, examples) comes from the word's own page
  function explain(x, n, q) {
    var url = href(x.r[2]);
    if (!url || url.indexOf('#') > -1 || url.indexOf('?') > -1) return;
    function put(html) {
      if (current !== q) return;
      var el = document.getElementById('ex' + n);
      if (el) el.innerHTML = html;
    }
    if (cache[url] != null) return put(cache[url]);
    fetch(url).then(function (res) { return res.ok ? res.text() : ''; }).then(function (t) {
      var html = '';
      if (t) {
        var doc = new DOMParser().parseFromString(t, 'text/html');
        var ex = doc.getElementById('explain');
        if (ex) {
          ex.querySelectorAll('a[href]').forEach(function (a) { a.setAttribute('href', new URL(a.getAttribute('href'), url).href); });
          html = ex.innerHTML;
        }
      }
      cache[url] = html;
      put(html);
    }).catch(function () { cache[url] = ''; });
  }

  function box() {
    var b = document.getElementById('results');
    if (!b) {
      var input = document.getElementById('q');
      if (!input || !input.form) return null;
      b = document.createElement('div');
      b.id = 'results';
      b.className = 'results';
      b.setAttribute('aria-live', 'polite');
      input.form.insertAdjacentElement('afterend', b);
    }
    return b;
  }

  function run(raw) {
    var b = box();
    if (!b) return;
    var q = norm(raw);
    current = q;
    var hint = document.getElementById('hint');
    if (hint) hint.hidden = !!q;
    if (!q) { b.innerHTML = ''; return; }
    if (!prep()) { b.innerHTML = '<div class="card"><p class="muted">Loading words\u2026</p></div>'; load(function () { if (current === q) run(raw); }); return; }
    var res = find(q), tried = q;
    if (!res.cards.length && !res.pre.length && /s$/.test(q) && q.length > 2) {
      // plural typed (\u201cwords\u201d): look for the singular (\u201cword\u201d)
      var alt = [q.slice(0, -1), q.replace(/es$/, '')], keep = res.other;
      for (var a = 0; a < alt.length; a++) {
        var r2 = find(alt[a]);
        if (r2.cards.length || r2.pre.length) { tried = alt[a]; res = r2; res.other = keep; break; }
      }
    }
    var h = '';
    res.cards.forEach(function (x, n) { h += card(x, n); });
    if (res.pre.length) {
      h += '<section class="card"><h2>Words starting with \u201c' + esc(tried === q ? raw.trim() : tried) + '\u201d</h2>';
      h += '<p class="muted small">' + res.pre.length + ' ' + (res.pre.length === 1 ? 'word' : 'words') + (res.pre.length > MAX ? ', first ' + MAX + ' shown. Type more letters to narrow it down.' : '') + '</p>';
      h += '<ul class="wl live">' + res.pre.slice(0, MAX).map(function (x) { return line(x, tried); }).join('') + '</ul></section>';
    }
    if (res.other.length && res.pre.length < 8) {
      h += '<section class="card"><h2>Other words that mention \u201c' + esc(raw.trim()) + '\u201d</h2><ul class="wl live">' +
        res.other.slice(0, 15).map(function (x) { return line(x, ''); }).join('') + '</ul></section>';
    }
    if (!h) h = '<div class="card"><p class="none">' + bi(UI.none, ['No words found', 'And\u00f9']) + '</p></div>';
    b.innerHTML = h;
    res.cards.forEach(function (x, n) { explain(x, n, q); });
  }

  var loading = null;
  function load(cb) {
    if (window.UDEL) return cb();
    if (!loading) {
      loading = [];
      var s = document.createElement('script');
      s.src = href('assets/words.js') + (window.UDEL_V ? '?v=' + window.UDEL_V : '');
      s.onload = function () { loading.forEach(function (f) { f(); }); };
      document.head.appendChild(s);
    }
    loading.push(cb);
  }

  // word of the day: a different everyday word each day (same word for everyone that day)
  function wotd() {
    var L = window.UDEL_WOTD, box = document.getElementById('wotd');
    if (!L || !L.length || !box) return;
    var d = new Date(), day = Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5);
    var x = L[day % L.length], u = href(x.u);
    box.innerHTML = '<div class="kicker">Word of the day</div>' +
      '<a class="w" lang="tbl" href="' + esc(u) + '">' + esc(x.w) + '</a>' +
      (x.p ? '<div class="pron">' + esc(x.p) + '</div>' : '') +
      '<div class="gloss">' + esc(x.g) + '</div>' +
      '<div class="example"><div class="tbx" lang="tbl">' + esc(x.t) + '</div><div class="enx">' + esc(x.e) + '</div></div>' +
      '<a class="more" href="' + esc(u) + '">See all forms of <span lang="tbl">' + esc(x.w) + '</span> \u2192</a>';
  }

  function init() {
    // old links went to index.html?q=...; search now has its own page
    var qs = new URLSearchParams(location.search).get('q');
    if (qs && document.getElementById('wotd')) { location.replace(href('search.html') + '?q=' + encodeURIComponent(qs)); return; }
    wotd();
    var input = document.getElementById('q');
    if (!input || !input.form) return;
    var home = !!document.getElementById('results');
    var q0 = home ? (new URLSearchParams(location.search).get('q') || '') : '';
    if (q0) { input.value = q0; run(q0); }
    input.addEventListener('focus', function () { load(function () {}); });
    var t;
    input.addEventListener('input', function () {
      clearTimeout(t);
      t = setTimeout(function () {
        run(input.value);
        if (home) {
          var u = new URL(location.href);
          if (input.value) u.searchParams.set('q', input.value); else u.searchParams.delete('q');
          history.replaceState(null, '', u);
        }
      }, 60);
    });
    input.form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (!home && input.value.trim()) { location.href = href('search.html') + '?q=' + encodeURIComponent(input.value.trim()); return; }
      run(input.value); input.blur();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
