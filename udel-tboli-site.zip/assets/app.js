(function () {
  // Accent-free, lower-case form so "kmati" finds "kmatì".
  function norm(s) {
    return (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/['\u2019]/g, '').trim();
  }
  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }
  var UI = window.UDEL_UI || {};
  function bi(pair) { return esc(pair[0]) + ' <span class="tb" lang="tbl">' + esc(pair[1]) + '</span>'; }

  function score(item, q) {
    // item: [hw, slug, short, aliases, english, forms, meaning, unconfirmed]
    var aliases = item[3].split('|'), eng = item[4] ? item[4].split('|') : [], forms = item[5] ? item[5].split('|') : [];
    var hw = aliases[0], s = 0;
    if (hw === q) s = 100;
    else if (aliases.indexOf(q) > -1) s = 95;
    else if (eng.indexOf(q) > -1) s = 90;
    else if (forms.indexOf(q) > -1) s = 80;
    else if (hw.indexOf(q) === 0) s = 70;
    else if (new RegExp('(^|[^a-z])' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^a-z]|$)').test(norm(item[2]))) s = 65;
    else if (eng.some(function (e) { return e.indexOf(q) === 0; })) s = 60;
    else if (new RegExp('(^|[^a-z])' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^a-z]|$)').test(item[6])) s = 45;
    else if (forms.some(function (f) { return f.indexOf(q) > -1; })) s = 35;
    else if (aliases.some(function (a) { return a.indexOf(q) > -1; })) s = 30;
    else if (q.length > 2 && item[6].indexOf(q) > -1) s = 15;
    return s;
  }

  function run(raw) {
    var box = document.getElementById('results');
    if (!box || !window.UDEL) return;
    var q = norm(raw);
    if (!q) { box.innerHTML = ''; return; }
    var hits = [];
    for (var i = 0; i < window.UDEL.length; i++) {
      var it = window.UDEL[i], sc = score(it, q);
      if (sc) hits.push([sc, it]);
    }
    hits.sort(function (a, b) { return b[0] - a[0] || a[1][0].length - b[1][0].length || (a[1][0] < b[1][0] ? -1 : 1); });
    if (!hits.length) {
      box.innerHTML = '<div class="card"><p class="none">' + bi(UI.none || ['No words found', '']) + '</p></div>';
      return;
    }
    var html = '<div class="card"><p class="muted small">' + hits.length + ' ' + bi(UI.words || ['words', '']) + '</p><ul>';
    hits.slice(0, 60).forEach(function (h) {
      var it = h[1];
      var badge = it[7] ? ' <span class="badge sm">' + bi(UI.unconf || ['Unconfirmed', '']) + '</span>' : '';
      html += '<li><a href="w/' + it[1] + '.html"><b lang="tbl">' + esc(it[0]) + '</b> <span>' + esc(it[2]) + '</span></a>' + badge + '</li>';
    });
    html += '</ul></div>';
    box.innerHTML = html;
  }

  document.addEventListener('DOMContentLoaded', function () {
    var input = document.getElementById('q');
    var form = input && input.form;
    if (!input || !document.getElementById('results')) return;
    var params = new URLSearchParams(location.search);
    var q0 = params.get('q') || '';
    if (q0) { input.value = q0; run(q0); }
    var t;
    input.addEventListener('input', function () {
      clearTimeout(t);
      t = setTimeout(function () {
        run(input.value);
        var u = new URL(location.href);
        if (input.value) u.searchParams.set('q', input.value); else u.searchParams.delete('q');
        history.replaceState(null, '', u);
      }, 120);
    });
    form.addEventListener('submit', function (ev) { ev.preventDefault(); run(input.value); input.blur(); });
  });
})();
