/* Udél T'boli: tabs and sideways-scrolling bars. Approved mockup (Oct 17), now on the live site.
   1. Gónô: Mon bê Mon / Udél bê udél tabs under the search box
   2. Sistéma Udél: section tabs in one sticky row that scrolls sideways
   3. Mebel: six random confirmed phrases before anyone types
   4. Kdéen mon: A–Z / Kem só (numbers and ordinals, built into the page by build.py) */
(function () {
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // keep the active tab visible inside a sideways bar, and light it up as the page scrolls
  function spy(bar, pairs) {
    function update() {
      var top = Math.max(bar.getBoundingClientRect().bottom + 12, 80), cur = pairs[0];
      pairs.forEach(function (p) { if (p[1].getBoundingClientRect().top <= top) cur = p; });
      pairs.forEach(function (p) { p[0].classList.toggle('on', p === cur); });
      var a = cur[0], l = a.offsetLeft - bar.offsetLeft;
      if (l < bar.scrollLeft + 16 || l + a.offsetWidth > bar.scrollLeft + bar.clientWidth - 16)
        bar.scrollLeft = l - (bar.clientWidth - a.offsetWidth) / 2;
    }
    pairs.forEach(function (p) {
      p[0].addEventListener('click', function (e) { e.preventDefault(); p[1].scrollIntoView({ behavior: 'smooth' }); if (history.replaceState && p[1].id) history.replaceState(null, '', '#' + p[1].id); });
    });
    window.addEventListener('scroll', update, { passive: true });
    update();
    return update;
  }

  // ---------- 1. Gónô: Word → word / Phrase → phrase ----------
  var mt = $('#mtabs');
  if (mt) {
    var input = $('#q'), ft = $('#ft'), help = $('#mhelp'), mode = 'word', ph0 = input.placeholder;
    ft.hidden = true;
    function setMode(m) {
      mode = m;
      $$('button', mt).forEach(function (b) { b.setAttribute('aria-selected', b.dataset.m === m); });
      ft.hidden = m !== 'phrase';
      var res = document.getElementById('results'); if (res) res.hidden = m === 'phrase';
      input.placeholder = m === 'phrase' ? 'Type a phrase · T\'boli or Inglis' : ph0;
      help.innerHTML = m === 'phrase'
        ? 'Type a whole sentence in T\'boli or <span lang="tbl">Inglis</span>. It comes back in Standard T\'boli, right here.'
        : 'Look up one word, in T\'boli or English. Same as the <span lang="tbl">Mebel</span> page.';
      if (m === 'phrase' && window.ftRun) window.ftRun(input.value);
      if (m === 'word' && input.value) input.dispatchEvent(new Event('input', { bubbles: true }));
    }
    mt.addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) setMode(b.dataset.m); });
    input.addEventListener('input', function (e) {
      if (mode === 'phrase') {
        e.stopImmediatePropagation();
        if (window.ftRun) window.ftRun(input.value);
        return;
      }
      // word results go under the tabs, not between the box and the tabs
      if (!document.getElementById('results')) {
        var r = document.createElement('div'); r.id = 'results'; r.className = 'results'; r.setAttribute('aria-live', 'polite');
        help.insertAdjacentElement('afterend', r);
      }
    });
    input.form.addEventListener('submit', function (e) {
      if (mode !== 'phrase') return;
      e.preventDefault(); e.stopImmediatePropagation(); input.blur();
    }, true);
    ft.addEventListener('click', function (e) {
      var t = e.target.closest('[data-try]'); if (t) input.value = t.dataset.try;
      var c = e.target.closest('[data-act=clear]'); if (c) { input.value = ''; input.focus(); }
    });
    window.udelMode = setMode;
  }

  // ---------- 2. Sistéma Udél: sticky tab bar ----------
  var gt = $('#gtabs');
  if (gt) spy(gt, $$('a', gt).map(function (a) { return [a, document.getElementById(a.getAttribute('href').slice(1))]; }).filter(function (p) { return p[1]; }));

  // ---------- 3. Mebel: random phrase suggestions ----------
  var sc = $('#schips');
  if (sc && window.UDEL_SUGG) {
    function deal() {
      var L = window.UDEL_SUGG.slice();
      for (var i = L.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = L[i]; L[i] = L[j]; L[j] = t; }
      sc.innerHTML = L.slice(0, 6).map(function (x) {
        return '<button type="button" data-q="' + esc(x.q) + '"><b lang="tbl">' + esc(x.t) + '</b><span>' + esc(x.e) + '</span></button>';
      }).join('');
    }
    deal();
    sc.insertAdjacentHTML('afterend', '<button type="button" class="reshuf" id="reshuf">↻ Show other phrases</button>');
    $('#reshuf').addEventListener('click', deal);
    sc.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var inp = $('#q'); inp.value = b.dataset.q; inp.dispatchEvent(new Event('input', { bubbles: true }));
    });
  }

  // ---------- 4. Kdéen mon: A–Z / Numerical words ----------
  var seg = $('#mseg');
  if (seg) {
    var vaz = $('#v-az'), vnum = $('#v-num'), azbar = $('#azbar'), built = false, upd = [];
    // A–Z: the letters jump down this page instead of opening a new one
    var azPairs = $$('a', azbar).map(function (a) { return [a, document.getElementById(a.textContent.trim().toLowerCase())]; }).filter(function (p) { return p[1]; });
    upd.push(spy(azbar, azPairs));
    function buildNum() {
      var nb = $('#numbar');
      if (nb) upd.push(spy(nb, $$('a', nb).map(function (a) { return [a, document.getElementById(a.getAttribute('href').slice(1))]; }).filter(function (p) { return p[1]; })));
      built = true;
    }
    function show(v) {
      $$('button', seg).forEach(function (b) { b.setAttribute('aria-selected', b.dataset.v === v); });
      vaz.hidden = v !== 'az'; vnum.hidden = v !== 'num';
      if (v === 'num' && !built) buildNum();
      window.scrollTo(0, 0);
      upd.forEach(function (f) { f(); });
    }
    seg.addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) show(b.dataset.v); });
    window.udelShow = show;
    // a-z/#kem-so opens Kem só; a-z/#gkati (etc.) opens it at that group
    var h = location.hash, hit = /^#g(1|11|10s|100s|1000s|kati|bil|ord)$/.test(h) && document.getElementById(h.slice(1));
    if (h === '#kem-so' || hit) { show('num'); if (hit) hit.scrollIntoView(); }
  }
})();
