/* Udél T'boli: free-typing "Build a phrase" (Sistéma Udél page, section 9, "Type it").
   Type anything in T'boli or Inglis. The tool:
   1. looks for a sentence Deymar confirmed (window.UDEL_BANK, assets/bank.js, built from tboli_dictionary.md by build.py),
   2. otherwise fixes what was typed with the grammar rules (accents, là + person first,
      deng before the action, he / dé / kdeng at the end, question word first),
   3. shows the result in Standard T'boli, flags anything not confirmed as Là deng tahu,
   4. lists other versions (Traditional, Bible, other ways to say it) in an optional section. */
(function () {
  var box = document.getElementById('ft'), inp = document.getElementById('ft-in'), out = document.getElementById('ft-out');
  var B = window.UDEL_BANK, UI = window.UDEL_UI || {};
  if (!box || !inp || !out || !B || !window.UDEL) return;   // without the data the tap builder stays as the only one
  var LEX = {}, ENG = {};
  (window.UDEL || []).forEach(function (r) {
    if (r[0] === 0) r[5].split('|').forEach(function (k) { if (k.indexOf(' ') < 0) (LEX[k] = LEX[k] || []).push({ w: r[1], url: r[2], m: r[3], unc: r[6] }); });
    else (ENG[r[5]] = ENG[r[5]] || []).push({ w: r[3].split(' / ')[0], url: r[10], m: r[1] });
  });

  // grammar words: what they do in a sentence (from the grammar section of the dictionary)
  var FN = {
    'e': 'I (the person word after là)', 'le': 'they', 'ye': 'you all', 'kuy': 'all of us', 'te': 'you and me',
    'he': 'at the end: yet', 'du': 'him, her, it; points back at the subject', 'dé': 'at the end: just, easygoing',
    'do': 'me, when it happens to me (from dou)', 'là': 'not', 'deng': 'done, already', 'meken': 'eating, the me- shape of ken (eat)',
    'denge': 'deng (already) + -e (I)', 'pati': 'believe (borrowed, no page yet)', 'okóm': 'but', 'ne': 'now, about to'
  };
  var PERSON = { e: 1, u: 1, le: 1, ye: 1, kuy: 1, te: 1, me: 1 };
  var QW = { bon: 'Bon', 'kmò': 'Kmò', 'nô': 'Nô', 'góem': 'Góem', tadu: 'Tadu', 'kilón': 'Kilón', moen: 'Moen' };
  var END = { he: 1, 'dé': 1, kdeng: 1 };

  function plain(s) { return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
  function key(s) { return plain(s).replace(/\([^)]*\)/g, ' ').replace(/[’']/g, '').replace(/[^a-z0-9\- ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  // every confirmed sentence, findable by its T'boli or its English
  var ALL = [];
  B.bank.forEach(function (b) { ALL.push({ tb: b.tb, en: b.en, src: b.src || 'Confirmed by Deymar', group: key(b.en) }); });
  B.tri.forEach(function (t, i) {
    ['std', 'trad', 'bible'].forEach(function (reg) { ALL.push({ tb: t[reg], en: t.en, reg: reg, tri: i, group: 'tri' + i }); });
  });
  function findTb(k) { for (var i = 0; i < ALL.length; i++) if (key(ALL[i].tb) === k) return ALL[i]; }
  function findEn(k) { for (var i = 0; i < ALL.length; i++) if (key(ALL[i].en) === k && ALL[i].reg !== 'trad' && ALL[i].reg !== 'bible') return ALL[i]; }

  function lookup(tok) {
    var c = LEX[plain(tok)];
    if (!c) return null;
    for (var i = 0; i < c.length; i++) if (c[i].w.toLowerCase() === tok) return c[i];
    return c.length === 1 ? c[0] : null;
  }

  var EN_WORDS = /\b(i|you|he|she|they|we|the|a|is|am|are|have|haven't|hasn't|not|already|yet|eat|eaten|ate|and|but|my|your|what|where|when|why|how|do|don't|it|very|hungry|going)\b/g;
  function isEnglish(text) {
    var w = key(text).split(' ').filter(Boolean), en = (key(text).match(EN_WORDS) || []).length, tb = 0;
    w.forEach(function (x) { if (LEX[x] && !/^(i|a|the|is)$/.test(x)) tb++; });
    return en > tb;
  }

  // ---------- T'boli: fix with the rules ----------
  function fixTboli(raw) {
    var toks = key(raw).split(' ').filter(Boolean), changes = [], rules = [], unknown = [];
    // accents
    toks = toks.map(function (t) {
      var e = lookup(t);
      if (e && e.w.toLowerCase() !== t && e.w.indexOf(' ') < 0 && e.w.indexOf('/') < 0) {
        changes.push(['<s>' + esc(t) + '</s> → <b>' + esc(e.w.toLowerCase()) + '</b>', 'Accent added. Accents change the meaning.', 'Sound rules']);
        return e.w.toLowerCase();
      }
      if (!e && !FN[t]) unknown.push(t);
      return t;
    });
    // question word first
    var qi = toks.findIndex(function (t) { return QW[t]; });
    if (qi > 0) { var q = toks.splice(qi, 1)[0]; toks.unshift(q); changes.push(['<b>' + esc(QW[q]) + '</b> moved to the front', 'The question word goes first.', '8 · Ask']); }
    // là + person go first, person right after là
    var li = toks.indexOf('là');
    if (li >= 0) {
      var pi = toks.findIndex(function (t, i) { return PERSON[t] && i !== li + 1; });
      if (pi >= 0 && toks[li + 1] && !PERSON[toks[li + 1]]) {
        var p = toks.splice(pi, 1)[0]; li = toks.indexOf('là'); toks.splice(li + 1, 0, p);
        changes.push(['<b>' + esc(p) + '</b> moved right after <b>là</b>', 'Là plus the person goes first: <em>Là ' + esc(p) + '</em>.', '2 · Not']);
      }
      li = toks.indexOf('là');
      if (li > 0) { var grp = toks.splice(li, PERSON[toks[li + 1]] ? 2 : 1); toks = grp.concat(toks); changes.push(['<b>' + esc(grp.join(' ')) + '</b> moved to the front', 'Là and its person start the sentence.', '2 · Not']); }
      rules.push(['2', 'not', 'Not', '<em>Là</em> plus the person goes first' + (PERSON[toks[1]] ? ': <em>Là ' + esc(toks[1]) + '</em>.' : '.'), 1]);
    }
    // deng before the action
    var di = toks.indexOf('deng'), vi = toks.indexOf('meken');
    if (di > vi && vi >= 0) {
      toks.splice(di, 1); toks.splice(toks.indexOf('meken'), 0, 'deng');
      changes.push(['<b>deng</b> moved before <b>meken</b>', '<em>Deng</em> (done, already) goes in front of the action.', '6 · Time']);
    }
    if (toks.indexOf('deng') >= 0) rules.push(['6', 'time', 'Time', '<em>deng</em> (done, already) goes before the action.', 1]);
    // he, dé, kdeng at the end
    toks.slice().forEach(function (t, i) {
      if (END[t] && toks.indexOf(t) !== toks.length - 1) {
        toks.splice(toks.indexOf(t), 1); toks.push(t);
        changes.push(['<b>' + esc(t) + '</b> moved to the end', '<em>' + esc(t) + '</em> goes at the end of the sentence.', '6 · Time']);
      }
    });
    if (toks.indexOf('he') >= 0) rules.push(['6', 'time', 'Time', '<em>he</em> at the end adds “yet”.', 1]);
    var s = cap(toks.join(' ')) + (QW[toks[0]] ? '?' : '.');
    // meaning, for the one pattern the rules can read back: Là + person + deng meken he
    var EN_BACK = { e: 'I', u: 'You', le: 'They', ye: 'You all', kuy: 'We' }, en = null, mm = s.match(/^Là (e|u|le|ye|kuy) deng meken he\.$/);
    if (mm) en = EN_BACK[mm[1]] + ' haven\'t eaten yet.';
    return { s: s, en: en, changes: changes, rules: rules, unknown: unknown };
  }

  // ---------- Inglis: a few rule patterns for eat (the action with the most confirmed forms) ----------
  var EN_P = { i: 'e', you: 'u', they: 'le', 'you all': 'ye', we: 'kuy' };
  var EN_N = { i: 'I', you: 'you', they: 'they', 'you all': 'you all', we: 'we' };
  function fromEnglish(raw) {
    var k = key(raw), m = k.match(/^(i|you all|you|they|we) (?:havent|have not) eaten yet$/);
    if (m) {
      var p = EN_P[m[1]];
      if (p === 'e') return { s: 'Lae deng meken.', en: 'I haven\'t eaten yet.', changes: [], rules: [['2', 'not', 'Not', 'Standard T\'boli joins là and the I word: <em>Lae</em>. <em>Là e deng meken he</em> is another version (Deymar, Oct 17).', 1]], unknown: [] };
      return { s: 'Là ' + p + ' deng meken he.', en: cap(EN_N[m[1]]) + ' haven\'t eaten yet.', changes: [],
        rules: [['2', 'not', 'Not', '<em>Là</em> plus the person goes first: <em>Là ' + p + '</em>.', 1], ['6', 'time', 'Time', '<em>deng</em> (done, already) goes before the action.', 1], ['6', 'time', 'Time', '<em>he</em> at the end adds “yet”.', 1]], unknown: [] };
    }
    // word for word, missing words kept in [brackets]
    var out = [], unknown = [];
    k.split(' ').forEach(function (w) { var e = ENG[w]; if (e) out.push(e[0].w); else { out.push('[' + w + ']'); unknown.push(w); } });
    return { s: cap(out.join(' ')) + '.', en: raw, changes: [], rules: [], unknown: unknown, rough: 1 };
  }

  // ---------- other versions ----------
  function others(res) {
    var o = [];
    if (res.hit && res.hit.tri !== undefined) {
      var t = B.tri[res.hit.tri];
      o.push(['Traditional', t.trad, 1, t.trad === t.std ? 'Same as Standard.' : '']);
      o.push(['Bible', t.bible, 1, '']);
    }
    if (res.hit) ALL.forEach(function (a) {
      if (a !== res.hit && a.group === res.hit.group && a.reg === undefined && key(a.tb) !== key(res.s)) o.push(['Other way to say it', a.tb, 1, '']);
    });
    if (!res.hit && /^Là (le|ye|me) /.test(res.s)) {
      var w = res.s.replace(/[.?]$/, '').split(' '), p = w[1];
      o.push(['Traditional', res.s, 0, 'Same order. A person word right after là is the traditional order (Deymar, Oct 16).']);
      var bib = [w[0]].concat(w.slice(2, w.indexOf('meken') + 1), [p], w.slice(w.indexOf('meken') + 1)).join(' ') + '.';
      o.push(['Bible', bib, 0, 'The person after the action sounds Biblical (Là pati le du yóm monu). Where <em>he</em> goes is a guess.']);
      o.push(['Note', 'Là ' + p, 1, '<em>' + p + '</em> is a separate word, so it never joins là the way <em>Lae</em> does.']);
    }
    return o;
  }

  // ---------- work out a result ----------
  function run(raw, mode) {
    var eng = mode === 'en' || (mode === 'auto' && isEnglish(raw)), res;
    if (eng) {
      var hit = findEn(key(raw));
      res = hit ? { s: hit.tb, en: hit.en, hit: hit, changes: [], rules: [], unknown: [] } : fromEnglish(raw);
    } else {
      var exact = findTb(key(raw));
      if (exact) {
        // a confirmed sentence: only spelling (accents) can differ
        var a = key(raw).split(' '), bw = exact.tb.replace(/[.?!,]/g, '').split(/\s+/), ch = [];
        a.forEach(function (t, i) { if (bw[i] && bw[i].toLowerCase() !== t) ch.push(['<s>' + esc(t) + '</s> → <b>' + esc(bw[i].toLowerCase()) + '</b>', 'Accent added. Accents change the meaning.', 'Sound rules']); });
        res = { changes: ch, rules: [], unknown: [] };
      } else res = fixTboli(raw);
      var h2 = exact || findTb(key(res.s));
      if (h2) {
        if (h2.reg && h2.reg !== 'std') { res.changes.push(['You typed the ' + (h2.reg === 'bible' ? 'Bible' : 'Traditional') + ' version', 'Standard T\'boli is shown here. Your version is under Other versions.', '']); h2 = ALL.filter(function (a) { return a.tri === h2.tri && a.reg === 'std'; })[0]; }
        // Standard for "I haven't eaten yet" is Lae deng meken; Là e deng meken he is close too, kept as another version (Deymar, Oct 17)
        if (key(h2.tb) === 'la e deng meken he') { res.changes.push(['You typed another version', 'Close, and not wrong. Standard T\'boli says <em>Lae deng meken</em>. Your version is under Other versions.', '']); h2 = findTb('lae deng meken') || h2; }
        res.hit = h2; res.s = h2.tb; res.en = h2.en;
      } else res.enRule = !!res.en;
    }
    res.eng = eng; res.raw = raw;
    res.ok = !!res.hit && !res.unknown.length;
    if (/[^.?!]$/.test(res.s)) res.s += '.';
    res.others = others(res);
    return res;
  }

  // ---------- page ----------
  var mode = 'auto', last = null;
  var UNC = UI.unconf || ['Unconfirmed', 'Là deng tahu'];
  var MAIL = box.getAttribute('data-mail') || '';
  function badge(ok) {
    return ok ? '<span class="okb">✓ Confirmed by Deymar</span>' : '<span class="badge">' + esc(UNC[0]) + ' <span class="tb" lang="tbl">' + esc(UNC[1]) + '</span></span>';
  }
  function wordsOf(s) {
    return s.replace(/[.?!,]/g, ' ').split(/\s+/).filter(Boolean).map(function (w) {
      var lw = w.toLowerCase(), e = lookup(lw), g = FN[lw] || (e && e.m) || '';
      if (lw === 'denge' && e) return '<a href="' + esc(e.url) + '"><b lang="tbl">' + esc(w) + '</b><span class="m">' + esc(g) + ' <span class="badge sm">Là deng tahu</span><br><small>How Denge splits isn’t checked yet. The sentence is.</small></span><span class="go">→</span></a>';
      if (/^\[/.test(w)) return '<div class="miss"><b>' + esc(w) + '</b><span class="m">Not in the dictionary yet. Kept in Inglis.</span></div>';
      return e ? '<a href="' + esc(e.url) + '"><b lang="tbl">' + esc(w) + '</b><span class="m">' + esc(g) + '</span><span class="go">→</span></a>'
               : '<div class="miss"><b lang="tbl">' + esc(w) + '</b><span class="m">' + esc(g || 'No page yet') + '</span></div>';
    }).join('');
  }
  function render(res) {
    last = res;
    if (!res) { out.innerHTML = ''; box.classList.add('empty'); return; }
    box.classList.remove('empty');
    var h = '<div class="res' + (res.ok ? ' ok' : ' unc') + '" aria-live="polite">' +
      '<div class="rhead"><span class="rlab">Standard T\'boli</span>' + badge(res.ok) + '</div>' +
      '<div class="say" lang="tbl">' + esc(res.s) + '</div>' +
      '<div class="eng">' + (res.en ? esc(res.en) + (res.enRule ? ' <span class="muted small">(meaning read from the rules)</span>' : '') : '<span class="muted">Meaning not worked out yet</span>') + '</div>' +
      (res.ok ? '<div class="note okn">Deymar taught or checked this exact sentence.</div>'
              : '<div class="note">' + (res.rough ? 'Word for word only. Grammar for this isn’t worked out yet.' : 'Built from the grammar rules. Deymar hasn’t checked this sentence yet.') + '</div>') +
      '<div class="typed">You typed' + (res.eng ? ' in Inglis' : ' in T\'boli') + ': <i>' + esc(res.raw) + '</i></div></div>';
    if (res.others.length) {
      h += '<details class="oth"' + (box.dataset.open ? ' open' : '') + '><summary><span>Other versions</span><small>optional · ' + res.others.length + '</small></summary><ul>' +
        res.others.map(function (o) {
          return '<li><div class="ol">' + esc(o[0]) + (o[0] === 'Note' ? '' : (o[2] ? ' <span class="okb sm">✓</span>' : ' <span class="badge sm">Là deng tahu</span>')) + '</div>' +
            '<div class="ot" lang="tbl">' + esc(o[1]) + '</div>' + (o[3] ? '<div class="on">' + o[3] + '</div>' : '') + '</li>';
        }).join('') + '</ul></details>';
    }
    if (res.changes.length) {
      h += '<div class="step"><div class="lab">What the rules fixed</div><ul class="fixes">' + res.changes.map(function (c) {
        return '<li><div class="fx">' + c[0] + '</div><div class="why">' + (c[2] ? '<span class="rn">' + esc(c[2]) + '</span>' : '') + '<span>' + c[1] + '</span></div></li>';
      }).join('') + '</ul></div>';
    }
    h += '<div class="step"><div class="lab">Word by word · tap a word to open it</div><div class="wbw">' + wordsOf(res.s) + '</div></div>';
    if (res.rules.length && !res.changes.length) h += '<div class="step"><div class="lab">Rules used</div><ul class="rules">' + res.rules.map(function (r) { return '<li><span class="rn">' + r[0] + ' · ' + r[2] + '</span><span>' + r[3] + '</span></li>'; }).join('') + '</ul></div>';
    h += '<div class="reset"><button type="button" class="a" data-act="clear">Start over</button><button type="button" class="b" data-act="copy">Copy</button>' + (res.ok || !MAIL ? '' : '<button type="button" class="b" data-act="send">Send to Deymar to check</button>') + '</div>';
    out.innerHTML = h;
  }
  function go() { var v = inp.value.trim(); render(v ? run(v, mode) : null); }
  function copy(b) {
    if (!last) return;
    var text = last.s + (last.en ? ' (' + last.en.replace(/[.]$/, '') + ')' : '');
    function done() { var o = b.textContent; b.textContent = 'Copied'; setTimeout(function () { b.textContent = o; }, 1400); }
    if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(done, function () {}); return; }
    var t = document.createElement('textarea');
    t.value = text; t.setAttribute('readonly', ''); t.style.position = 'absolute'; t.style.left = '-999px';
    document.body.appendChild(t); t.select();
    try { document.execCommand('copy'); done(); } catch (err) {}
    document.body.removeChild(t);
  }
  function send() {
    if (!last || !MAIL) return;
    var body = 'Please check this phrase.\n\nI typed: ' + last.raw + '\nThe site gave (Standard T\'boli): ' + last.s +
      '\nMeaning: ' + (last.en || 'not worked out yet') + '\n\nIs it right? If not, how would you say it?\n\nYour name and town (optional):\n';
    location.href = 'mailto:' + MAIL + '?subject=' + encodeURIComponent('Udél phrase to check: ' + last.s) + '&body=' + encodeURIComponent(body);
  }
  inp.addEventListener('input', go);
  box.addEventListener('click', function (e) {
    var a = e.target.closest('[data-act]');
    if (a) {
      var act = a.getAttribute('data-act');
      if (act === 'clear') { inp.value = ''; go(); inp.focus(); }
      else if (act === 'copy') copy(a);
      else if (act === 'send') send();
      return;
    }
    var b = e.target.closest('[data-mode]');
    if (b) { mode = b.dataset.mode; box.querySelectorAll('[data-mode]').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); go(); }
    var t = e.target.closest('[data-try]');
    if (t) { inp.value = t.dataset.try; go(); }
  });
  window.ftRun = function (text, open) { inp.value = text; if (open) box.dataset.open = 1; go(); };

  // ---------- Type it / Tap it switch (the tap builder keeps working exactly as before) ----------
  var sw = document.querySelector('#build .bswitch'), tap = document.getElementById('tap');
  function show(p) {
    box.hidden = p !== 'ft';
    if (tap) tap.hidden = p !== 'tap';
    if (sw) sw.querySelectorAll('[data-pane]').forEach(function (x) { x.setAttribute('aria-pressed', x.getAttribute('data-pane') === p); });
  }
  if (sw) {
    sw.hidden = false;
    sw.addEventListener('click', function (e) { var b = e.target.closest('[data-pane]'); if (b) show(b.getAttribute('data-pane')); });
  }
  show(location.hash === '#tap' ? 'tap' : 'ft');
  var q = new URLSearchParams(location.search).get('say');
  if (q) { inp.value = q; go(); }
})();
