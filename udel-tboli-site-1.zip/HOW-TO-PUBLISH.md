# Putting Udél T'boli online from your Android phone

This takes about 20 minutes and it's free. You only need Chrome and the Files app. You don't unpack the whole site: you upload the zips as they are, plus one small file from inside the site zip, and GitHub unpacks and publishes it for you.

There are two zips. **udel-tboli-site.zip** is the site itself. **udel-tboli-sounds.zip** holds the recordings the play buttons use. Both go in the same place, still zipped.

If a button below is missing on your phone, open Chrome's menu (the three dots at the top right) and tick **Desktop site**. GitHub's phone layout hides some buttons.

## 1. Make a GitHub account

1. Go to **github.com** and tap **Sign up**.
2. Enter your email, a password and a username. Pick the username with care: it becomes part of your site's address, `https://username.github.io/udel-tboli/`.
3. Type in the code GitHub emails you.

## 2. Create the repository

1. Tap the **+** at the top, then **New repository**.
2. Repository name: `udel-tboli` (exactly this, all small letters).
3. Choose **Public**.
4. Tick **Add a README file**.
5. Tap **Create repository**.

## 3. Turn on Pages

Do this before you upload, so the site goes live on the first try.

1. In the repository, tap **Settings** (in the row of tabs; scroll the tabs sideways if you don't see it).
2. In the left menu, tap **Pages**.
3. Under **Build and deployment**, set **Source** to **GitHub Actions**. That's all on this page.

## 4. Take one file out of the zip

1. Open the **Files** app and go to **Downloads**.
2. Tap the zip, then **Extract**.
3. In the new folder, find **publish.yml**. That's the file that tells GitHub how to publish. Keep the original zip too.

## 5. Upload the files

1. Go back to the repository's main page (the **Code** tab).
2. Tap **Add file**, then **Upload files**, then **choose your files**.
3. Pick **udel-tboli-site.zip** and **udel-tboli-sounds.zip** (both still zipped), then add **publish.yml** too.
4. Tap **Commit changes**.

## 6. Put publish.yml in its place

GitHub only runs it from a folder called `.github/workflows`.

1. Tap **publish.yml** in the file list, then the **pencil** (Edit).
2. Tap at the very start of the file name box, before the p, and type `.github/workflows/` so the name reads `.github/workflows/publish.yml`.
3. Tap **Commit changes**, then **Commit changes** again.

This starts the publishing. Tap the **Actions** tab: after 1 to 2 minutes the run shows a green tick. Your site is now at `https://username.github.io/udel-tboli/`, with your own GitHub username in small letters.

If the run shows a red X, check step 3 (Source must be GitHub Actions), then in **Actions** open the run and tap **Re-run all jobs**.

## Where USERNAME is

The files use the placeholder address `https://USERNAME.github.io/udel-tboli/`. It appears in **sitemap.xml**, **robots.txt**, and in the hidden `canonical` and share lines at the top of every page. You don't need to change it: the publish step puts your real username in its place every time it runs. You'd only replace USERNAME by hand if you ever uploaded the loose files without publish.yml.

## 7. Tell Google about the site

1. Open **search.google.com/search-console** and sign in with your Google account.
2. Tap **Add property** (or the property menu at the top left), choose **URL prefix**, and paste your address, like `https://username.github.io/udel-tboli/`. Tap **Continue**.
3. Choose the **HTML file** method and tap the download button. You get a small file named like `google1234abcd.html`.
4. In GitHub, **Add file** → **Upload files**, pick that google file, and **Commit changes**. Wait for the green tick in **Actions** (1 to 2 minutes).
5. Back in Search Console, tap **Verify**.
6. In the Search Console menu, tap **Sitemaps**, type `sitemap.xml`, and tap **Submit**. That gives Google the list of every word page.
7. Optional: tap **URL inspection**, paste your home address, and tap **Request indexing**.

Google can take a few days to a few weeks to show the word pages in search.

## Updating the site later

Usually only the site zip changes. publish.yml, the google file and the sounds zip stay as they are. You only upload the sounds zip again when the recordings change.

1. Save the new **udel-tboli-site.zip** on your phone (and **udel-tboli-sounds.zip** if it's new too). Don't unpack them.
2. In Chrome, open **github.com/tbolilanguage/udel-tboli** (the **Code** tab). If a button is missing, open Chrome's menu and tick **Desktop site**.
3. Tap **Add file**, then **Upload files**, then **choose your files**, and pick the zip (or both zips).
4. Keep **Commit directly to the main branch** selected and tap **Commit changes**. A file with the same name replaces the old one.
5. Look at the file list: there should be one site zip and one sounds zip. If your phone saved one as `udel-tboli-site (1).zip`, tap the old `udel-tboli-site.zip`, tap the three dots (or the bin icon), choose **Delete file**, and commit. Do the same for an old sounds zip.
6. Committing to main republishes the site by itself. Tap the **Actions** tab and wait 1 to 2 minutes for the green tick. Then open the site and refresh the page. If the old look still shows, close the tab and open the site again.

## This update: play buttons (do this once)

This update adds the **Hnungol** (Listen) play buttons, and the sounds come in their own zip. The old publish.yml doesn't know about the sounds zip, so this one time you also replace publish.yml. Without that, the site still works, but the play buttons say "Sound not found".

1. Take the new **publish.yml** out of the new site zip (step 4 above).
2. In GitHub, open the **.github** folder, then **workflows**, then tap **publish.yml**. Tap the three dots (or the bin icon), choose **Delete file**, and commit.
3. Go back to the **Code** tab. **Add file** → **Upload files**, and pick **udel-tboli-site.zip**, **udel-tboli-sounds.zip** and the new **publish.yml**. Commit.
4. Move publish.yml into place exactly like step 6 above. That starts the publishing.
5. In **Actions**, open the run and tap **Unpack the site**: it should say "Sound clips:" with a number above 2,000.

If the sounds ever come as more than one zip (udel-tboli-sounds-1.zip, udel-tboli-sounds-2.zip ...), upload all of them the same way. publish.yml picks up every sounds zip.
