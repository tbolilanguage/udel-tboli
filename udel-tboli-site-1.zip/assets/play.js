/* Udél T'boli: Play buttons.
   Every button carries data-clip="<id>" and plays sounds/<id>.mp3, a clip made ahead of time with the T'boli voice.
   Only one thing plays at a time. While it plays, the button turns into a red stop button and its row turns pink. */
(function () {
  var PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>';
  var STOP = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6.5" y="6.5" width="11" height="11" rx="2" fill="currentColor"/></svg>';
  var BARS = '<span class="bars" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span>';
  var me = document.currentScript;
  var ROOT = me && me.src ? new URL('../', me.src).href : new URL(window.UDEL_ROOT || '', location.href).href;
  var audio = null, cur = null, timer = null;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }
  // html for the builders (they draw their results as text)
  function btn(clip, label) {
    if (!clip) return none();
    return '<button type="button" class="pb" data-clip="' + esc(clip) + '" aria-label="' + esc('Play: ' + (label || '')) + '">' + PLAY + '</button>';
  }
  function none() {
    return '<span class="nrecw"><button type="button" class="pb none" disabled aria-label="No recording yet">' + PLAY + '</button><span class="nrec">No recording</span></span>';
  }
  function big(clip, label) {
    if (!clip) return '<button type="button" class="pbig none" disabled><span class="ic2">' + PLAY + '</span><span class="lb"><span>No recording yet</span><small>Only checked sentences have one</small></span></button>';
    return '<button type="button" class="pbig" data-clip="' + esc(clip) + '" aria-label="' + esc('Hnungol (Listen): ' + (label || '')) + '"><span class="ic2">' + PLAY + '</span><span class="lb"><span lang="tbl">Hnungol</span><small>Listen</small></span></button>';
  }

  function rowOf(b) { return b.classList.contains('pbig') ? null : b.closest('li, .wrow, .example, .orow'); }
  function fmt(t) { t = Math.max(0, Math.floor(t || 0)); return Math.floor(t / 60) + ':' + ('0' + (t % 60)).slice(-2); }

  function turnOn(b) {
    b._lab = b.getAttribute('aria-label') || '';
    b._idle = b.innerHTML;
    b.classList.add('on');
    b.setAttribute('aria-label', 'Stop');
    b.setAttribute('aria-pressed', 'true');
    if (b.classList.contains('pbig')) b.innerHTML = '<span class="ic2">' + STOP + '</span><span class="lb"><span>Playing</span><small>Tap to stop</small></span>' + BARS + '<span class="tm">0:00</span>';
    else b.innerHTML = STOP;
    var r = rowOf(b);
    if (r) r.classList.add('playing');
  }
  function turnOff(b) {
    if (!b) return;
    b.classList.remove('on');
    if (b._idle != null) b.innerHTML = b._idle;
    b.setAttribute('aria-label', b._lab || 'Play');
    b.removeAttribute('aria-pressed');
    var r = rowOf(b);
    if (r) r.classList.remove('playing');
  }
  function stop() {
    clearInterval(timer);
    timer = null;
    if (audio) { audio.onended = audio.onerror = null; try { audio.pause(); } catch (e) {} audio = null; }
    var b = cur;
    cur = null;
    turnOff(b);
  }
  function fail(b) {
    if (cur !== b) return;
    stop();
    b.classList.add('err');
    var old = b.getAttribute('aria-label');
    b.setAttribute('aria-label', 'Sound not found');
    if (b.classList.contains('pbig')) {
      var s = b.querySelector('.lb small');
      if (s) { var t = s.textContent; s.textContent = 'Sound not found'; setTimeout(function () { s.textContent = t; }, 2500); }
    }
    setTimeout(function () { b.classList.remove('err'); b.setAttribute('aria-label', old); }, 2500);
  }
  function play(b) {
    var clip = b.getAttribute('data-clip');
    if (!clip) return;
    if (b === cur) { stop(); return; }   // tap again to stop
    stop();                                // only one thing plays at a time
    cur = b;
    turnOn(b);
    var a = new Audio(ROOT + 'sounds/' + clip + '.mp3');
    audio = a;
    a.onended = function () { if (audio === a) stop(); };
    a.onerror = function () { if (audio === a) fail(b); };
    var p = a.play();
    if (p && p.catch) p.catch(function (e) { if (audio === a && e && e.name !== 'AbortError') fail(b); });
    var tm = b.querySelector('.tm');
    if (tm) timer = setInterval(function () { if (audio === a) tm.textContent = fmt(a.currentTime); }, 250);
  }

  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('button.pb, button.pbig');
    if (!b || b.disabled || !b.hasAttribute('data-clip')) return;
    e.preventDefault();
    e.stopPropagation();
    play(b);
  });
  // a button that is drawn again (the builders redraw their results) stops its sound
  new MutationObserver(function () { if (cur && !document.body.contains(cur)) stop(); })
    .observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); });

  window.UDEL_PLAY = { btn: btn, big: big, none: none, stop: stop, PLAY: PLAY };
})();
