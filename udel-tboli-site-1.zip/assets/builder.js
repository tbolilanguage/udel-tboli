/* Build a phrase (Sistéma Udél page). Data comes from phrases.py through #bld-data.
   Only sentences Deymar confirmed are in the data; any other mix is a dashed, disabled button. */
(function () {
  var box = document.getElementById('build');
  var src = document.getElementById('bld-data');
  if (!box || !src) return;
  var D = JSON.parse(src.textContent);
  var UI = window.UDEL_UI || {};
  var KEYS = ['who', 'act', 'when', 'turn'];
  var NAMES = { who: 'who', act: 'the action', when: 'when', turn: 'how to make it' };
  var sel = { who: null, act: D.actions.length === 1 ? D.actions[0].key : null, when: null, turn: null };
  var stage = document.getElementById('bld-stage');
  var out = document.getElementById('bld-out');
  var EMPTY = stage.innerHTML;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }
  function badge() {
    var p = UI.unconf || ['Unconfirmed', 'L\u00e0 deng tahu'];
    return ' <span class="badge sm">' + esc(p[0]) + ' <span class="tb" lang="tbl">' + esc(p[1]) + '</span></span>';
  }
  function all() {
    var r = [];
    D.actions.forEach(function (a) { a.sentences.forEach(function (s) { r.push({ a: a, s: s }); }); });
    return r;
  }
  var ROWS = all();
  function val(row, k) { return k === 'act' ? row.a.key : row.s[k]; }
  // rows that fit the current picks, with one pick swapped for a candidate
  function fits(k, v) {
    return ROWS.some(function (row) {
      return KEYS.every(function (kk) {
        var want = kk === k ? v : sel[kk];
        return want == null || val(row, kk) === want;
      });
    });
  }
  function match() {
    if (KEYS.some(function (k) { return sel[k] == null; })) return null;
    for (var i = 0; i < ROWS.length; i++) {
      if (KEYS.every(function (k) { return val(ROWS[i], k) === sel[k]; })) return ROWS[i];
    }
    return null;
  }

  function paintButtons() {
    box.querySelectorAll('.pick button').forEach(function (b) {
      var k = b.getAttribute('data-k'), v = b.getAttribute('data-v');
      var on = sel[k] === v, ok = on || fits(k, v);
      b.classList.toggle('on', on);
      b.classList.toggle('off', !ok);
      b.disabled = !ok;
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
      if (!ok) b.title = "Deymar hasn't confirmed this mix yet"; else b.removeAttribute('title');
    });
  }

  function render() {
    paintButtons();
    var m = match();
    if (!m) {
      stage.className = 'stage empty';
      stage.innerHTML = EMPTY;
      var left = KEYS.filter(function (k) { return sel[k] == null; }).map(function (k) { return NAMES[k]; });
      var picked = KEYS.some(function (k) { return k !== 'act' && sel[k] != null; });
      if (picked && left.length) stage.querySelector('.hint').textContent = 'Now pick ' + left.join(', ').replace(/, ([^,]*)$/, ' and $1') + '.';
      out.innerHTML = picked ? '<div class="reset"><button type="button" class="a" data-do="reset">Start over</button></div>' : '';
      return;
    }
    var s = m.s, last = s.words.length - 1;
    var say = s.words.map(function (w, i) {
      return '<a href="' + esc(w[1]) + '">' + esc(w[0]) + '</a>' + (i === last ? '<span class="p">' + esc(s.end) + '</span>' : '');
    }).join(' ');
    var P = window.UDEL_PLAY;
    var also = s.also ? '<div class="also">Also said: <b lang="tbl">' + esc(s.also[0]) + '</b> (' + esc(s.also[1]) + ')' + (P && s.ca ? ' ' + P.btn(s.ca, s.also[0]).replace('class="pb"', 'class="pb sm il"') : '') + '</div>' : '';
    stage.className = 'stage';
    var sayHtml = '<div class="say" lang="tbl">' + say + '</div>';
    if (P) sayHtml = '<div class="sayrow">' + sayHtml + P.big(s.c, s.words.map(function (w) { return w[0]; }).join(' ') + s.end) + '</div>';
    stage.innerHTML = sayHtml + '<div class="eng">' + esc(s.en) + '</div>' + also;
    var wbw = s.words.map(function (w) {
      var a = '<a href="' + esc(w[1]) + '"><b lang="tbl">' + esc(w[0]) + '</b><span class="m">' + w[2] +
        '</span><span class="go" lang="tbl">' + esc(w[3]) + ' \u2192</span></a>';
      return P ? '<div class="wrow">' + a + P.btn(w[4], w[0]) + '</div>' : a;
    }).join('');
    var rules = s.rules.map(function (r) {
      var tag = r[0] ? '<a class="rn" href="#' + esc(r[1]) + '">' + esc(r[0]) + ' \u00b7 ' + esc(r[2]) + '</a>' : '<span class="rn">' + esc(r[2]) + '</span>';
      return '<li' + (r[4] ? '' : ' class="unc"') + '>' + tag + '<span>' + r[3] + (r[4] ? '' : badge() + '<span class="uncn">Deymar hasn\u2019t checked this explanation yet. The sentence itself is confirmed.</span>') + '</span></li>';
    }).join('');
    out.innerHTML = '<div class="step"><div class="lab">Word by word \u00b7 tap a word to open it</div><div class="wbw">' + wbw + '</div></div>' +
      '<div class="step"><div class="lab">Rules used</div><ul class="rules">' + rules + '</ul></div>' +
      '<div class="reset"><button type="button" class="a" data-do="reset">Start over</button><button type="button" class="b" data-do="copy">Copy sentence</button></div>';
  }

  function copy(btn) {
    var m = match(); if (!m) return;
    var text = m.s.words.map(function (w) { return w[0]; }).join(' ') + m.s.end;
    function done() { btn.textContent = 'Copied'; setTimeout(function () { btn.textContent = 'Copy sentence'; }, 1500); }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else fallback();
    function fallback() {
      var t = document.createElement('textarea');
      t.value = text; t.setAttribute('readonly', ''); t.style.position = 'absolute'; t.style.left = '-999px';
      document.body.appendChild(t); t.select();
      try { document.execCommand('copy'); done(); } catch (e) {}
      document.body.removeChild(t);
    }
  }

  box.addEventListener('click', function (ev) {
    var b = ev.target.closest('button');
    if (!b || !box.contains(b)) return;
    var act = b.getAttribute('data-do');
    if (act === 'reset') {
      KEYS.forEach(function (k) { if (!(k === 'act' && D.actions.length === 1)) sel[k] = null; });
      render();
      stage.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      return;
    }
    if (act === 'copy') { copy(b); return; }
    var k = b.getAttribute('data-k'), v = b.getAttribute('data-v');
    if (!k || b.disabled) return;
    if (k === 'act' && D.actions.length === 1) return;
    sel[k] = sel[k] === v ? null : v;
    render();
  });

  render();
})();
